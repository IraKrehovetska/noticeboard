<?php
	header('Content-type: text/html; charset=utf-8');
	date_default_timezone_set('Europe/Kiev');
	ini_set('sendmail_from','no-reply@noticeboard.url.ph');
	$db_user = 'u936235099_user';
	$db_pass = 'rehfuf';
	$db_db = 'u936235099_board';
	$db_host = 'localhost';
?>