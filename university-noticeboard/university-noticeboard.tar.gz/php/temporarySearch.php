<?php 
    $search=$ _POST[ 'search-input'] 
?>